# TasiaAddons.MetricsConnector v2

## What it does
An OpenSim region addon module that collects per-region metrics and exposes them via HTTP API. This replaces dotnet-monitor for metrics collection — no .NET IPC event pipe needed.

## Features
- **Sim stats** from SimStatsReporter: FPS, physics FPS, time dilation, agents, objects, scripts, frame timing, network packets, script lines/sec, pending downloads/uploads
- **.NET runtime metrics**: GC Gen0/1/2 collections, CPU time, thread pool stats, handle count, native threads, working set
- **HTTP request tracking** via listener event hook
- **Authenticatored HTTP API** per region
- No dotnet-monitor dependency — works with any OpenSim build

## Installation

1. Build `TasiaAddons.MetricsConnector.csproj` (targets net8.0)
2. Copy `TasiaAddons.MetricsConnector.dll` to the sim's `bin/` directory
3. Add `[MetricsConnector]` section to shared config (e.g., `GridCommon.ini`):

```ini
[MetricsConnector]
    Enabled = true
    ApiEnabled = true
    ApiToken = YOUR_SECRET_TOKEN_HERE
    CollectIntervalSeconds = 10
```

4. Restart sims

## API

### GET `/tasia-ngc/metrics/{regionUUID}`

**Headers:**
```
Authorization: Bearer YOUR_SECRET_TOKEN_HERE
```

**Response:**
```json
{
  "region_name": "River-Retreat",
  "sim_fps": 55.0,
  "physics_fps": 55.0,
  "time_dilation": 1.000,
  "agents": 5,
  "child_agents": 2,
  "objects": 1234,
  "active_objects": 500,
  "active_scripts": 56,
  "object_updates": 12,
  "frame_ms": 18.2,
  "net_ms": 2.1,
  "physics_ms": 3.5,
  "image_ms": 1.2,
  "other_ms": 4.3,
  "script_ms": 5.1,
  "agent_ms": 2.8,
  "in_packets_ps": 150,
  "out_packets_ps": 120,
  "unacked_bytes": 0,
  "script_eps": 450,
  "script_lines_ps": 1200.5,
  "pending_downloads": 3,
  "pending_uploads": 0,
  "memory_mb": 1024,
  "uptime_seconds": 3600,
  "gc_gen0": 1200,
  "gc_gen1": 50,
  "gc_gen2": 3,
  "cpu_seconds": 45.2,
  "thread_pool_threads": 8,
  "thread_pool_pending": 0,
  "thread_pool_completed": 15000,
  "handle_count": 350,
  "native_threads": 12,
  "working_set_mb": 980
}
```

## Config Options

| Key | Default | Description |
|-----|---------|-------------|
| `Enabled` | false | Enable the module |
| `ApiEnabled` | false | Enable HTTP API endpoint |
| `ApiToken` | empty | Bearer token for API auth |
| `ApiPathPrefix` | `/tasia-ngc/metrics` | API URL prefix |
| `CollectIntervalSeconds` | 10 | How often to collect stats |

## Architecture

```
Sim (OpenSim.dll)
  └─ MetricsConnector (INonSharedRegionModule)
       ├─ Timer: collects stats every 10s
       │   └─ Scene.StatsReporter (FPS, agents, objects, scripts, timing, network)
       │   └─ GC.GetTotalMemory, GC.CollectionCount (GC stats)
       │   └─ Process.GetCurrentProcess (CPU, handles, threads, working set)
       │   └─ ThreadPool (threads, pending work, completed work)
       └─ HTTP Handler: /tasia-ngc/metrics/{regionID}
           └─ Returns JSON with all collected metrics
```

## Stats Index Reference (from SimStatsReporter)

| Index | Field | Description |
|-------|-------|-------------|
| 0 | TimeDilation | Region time dilation (0-1) |
| 1 | SimFPS | Simulator frames per second |
| 2 | PhysicsFPS | Physics engine FPS |
| 3 | AgentUpdates | Object updates sent to viewers |
| 4 | Agents | Root agents in view |
| 5 | ChildAgents | Child agents |
| 6 | TotalPrim | Total objects |
| 7 | ActivePrim | Active/moving objects |
| 8 | FrameMS | Average frame time (ms) |
| 9 | NetMS | Network processing time (ms) |
| 10 | PhysicsMS | Physics processing time (ms) |
| 11 | ImageMS | Image loading time (ms) |
| 12 | OtherMS | Other processing time (ms) |
| 13 | InPacketsPerSecond | Incoming packets/sec |
| 14 | OutPacketsPerSecond | Outgoing packets/sec |
| 15 | UnAckedBytes | Unacknowledged bytes |
| 16 | AgentMS | Agent processing time (ms) |
| 17 | PendingDownloads | Pending asset downloads |
| 18 | PendingUploads | Pending asset uploads |
| 19 | ActiveScripts | Running scripts |
| 28 | ScriptEps | Script events per second |
| 37 | ScriptMS | Script processing time (ms) |
| 38 | LSLScriptLinesPerSecond | LSL lines executed/sec |
