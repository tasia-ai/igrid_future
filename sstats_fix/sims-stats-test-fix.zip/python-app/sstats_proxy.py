#!/usr/bin/env python3
"""
SStats MySQL Dashboard — Password-Shielded HTTP Stats for OpenSim
=================================================================
Reads/writes the SAME `stats_session_data` table that the C# WebStatsModule
uses (via SQLite or MySQL). Connects to the SAME MySQL database OpenSim uses.

Architecture:
  ┌──────────────┐     writes      ┌─────────────┐     reads      ┌──────────────────┐
  │ OpenSim      │ ──────────────> │ MySQL DB    │ <───────────── │ Python SStats    │
  │ (C# SStats)  │                 │ opensim     │                │ Dashboard :8080  │
  └──────────────┘                 └─────────────┘                │ (password-       │
                                     ^  stats_session_data        │  shielded)       │
                                     |  table (shared)            └──────────────────┘

Features:
  - Connects to the same MySQL as OpenSim (same connection string)
  - Creates `stats_session_data` table if missing (same schema as C# module)
  - Password-shielded web dashboard (HTTP Basic Auth + session cookies)
  - Real-time stats: users, sessions, FPS, ping, bandwidth, client versions
  - JSON API endpoint for programmatic access
  - Rate limiting, session management, access logging
  - Can also INSERT stats data (acts as a stats collector)

Usage:
    # Same MySQL as OpenSim:
    MYSQL_HOST=localhost \
    MYSQL_DB=opensim \
    MYSQL_USER=opensim \
    MYSQL_PASS=yourpassword \
    PROXY_USERNAME=admin \
    PROXY_PASSWORD=changeme \
    python sstats_proxy.py

    # Or via docker-compose (env vars from .env)
    docker-compose up

Requirements:
    pip install pymysql

OpenSim Robust.ini MySQL format:
    Data Source=localhost;Database=opensim;User ID=opensim;Password=***;Old Guids=true;SslMode=None;
"""

import os
import sys
import time
import json
import hashlib
import hmac
import secrets
import logging
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, unquote
from datetime import datetime, timezone
from collections import defaultdict
import base64
import html

# Optional: MySQL via PyMySQL (pure Python, no C deps)
try:
    import pymysql
    pymysql.install_as_MySQLdb()
    import MySQLdb
    HAS_MYSQL = True
except ImportError:
    HAS_MYSQL = False
    print("[WARNING] pymysql not installed. Install with: pip install pymysql")
    print("          Running in DEMO mode with mock data.")


# =============================================================================
# Configuration (from environment — mirrors OpenSim's Robust.ini format)
# =============================================================================
# MySQL connection (same as OpenSim)
MYSQL_HOST = os.environ.get("MYSQL_HOST", "localhost")
MYSQL_PORT = int(os.environ.get("MYSQL_PORT", "3306"))
MYSQL_DB = os.environ.get("MYSQL_DB", "opensim")
MYSQL_USER = os.environ.get("MYSQL_USER", "opensim")
MYSQL_PASS = os.environ.get("MYSQL_PASS", "")
MYSQL_CHARSET = os.environ.get("MYSQL_CHARSET", "utf8mb4")
MYSQL_TABLE = os.environ.get("MYSQL_TABLE", "stats_session_data")

# Dashboard auth
PROXY_PORT = int(os.environ.get("PROXY_PORT", "8080"))
PROXY_HOST = os.environ.get("PROXY_HOST", "0.0.0.0")
PROXY_USERNAME = os.environ.get("PROXY_USERNAME", "admin")
PROXY_PASSWORD = os.environ.get("PROXY_PASSWORD", "changeme")
SESSION_SECRET = os.environ.get("SESSION_SECRET", secrets.token_hex(32))
SESSION_TIMEOUT = int(os.environ.get("SESSION_TIMEOUT", "3600"))
MAX_LOGIN_ATTEMPTS = int(os.environ.get("MAX_LOGIN_ATTEMPTS", "5"))
LOGIN_LOCKOUT_SECONDS = int(os.environ.get("LOGIN_LOCKOUT_SECONDS", "300"))

# Optional: OpenSim SStats upstream for proxy mode
UPSTREAM_URL = os.environ.get("SSTATS_UPSTREAM", "")  # empty = direct MySQL mode


# =============================================================================
# Logging
# =============================================================================
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)
log = logging.getLogger("sstats-mysql")


# =============================================================================
# MySQL Database Layer
# =============================================================================
# This is the EXACT same table schema the C# WebStatsModule creates.
# If the C# module already created it, we just read from it.
# If not, we create it here so both can coexist.

SQL_CREATE_TABLE = """CREATE TABLE IF NOT EXISTS `{table}` (
    session_id VARCHAR(36) NOT NULL PRIMARY KEY,
    agent_id VARCHAR(36) NOT NULL DEFAULT '',
    region_id VARCHAR(36) NOT NULL DEFAULT '',
    last_updated INT NOT NULL DEFAULT 0,
    remote_ip VARCHAR(16) NOT NULL DEFAULT '',
    name_f VARCHAR(50) NOT NULL DEFAULT '',
    name_l VARCHAR(50) NOT NULL DEFAULT '',
    avg_agents_in_view FLOAT NOT NULL DEFAULT 0,
    min_agents_in_view INT NOT NULL DEFAULT 0,
    max_agents_in_view INT NOT NULL DEFAULT 0,
    mode_agents_in_view INT NOT NULL DEFAULT 0,
    avg_fps FLOAT NOT NULL DEFAULT 0,
    min_fps FLOAT NOT NULL DEFAULT 0,
    max_fps FLOAT NOT NULL DEFAULT 0,
    mode_fps FLOAT NOT NULL DEFAULT 0,
    a_language VARCHAR(25) NOT NULL DEFAULT '',
    mem_use FLOAT NOT NULL DEFAULT 0,
    meters_traveled FLOAT NOT NULL DEFAULT 0,
    avg_ping FLOAT NOT NULL DEFAULT 0,
    min_ping FLOAT NOT NULL DEFAULT 0,
    max_ping FLOAT NOT NULL DEFAULT 0,
    mode_ping FLOAT NOT NULL DEFAULT 0,
    regions_visited INT NOT NULL DEFAULT 0,
    run_time FLOAT NOT NULL DEFAULT 0,
    avg_sim_fps FLOAT NOT NULL DEFAULT 0,
    min_sim_fps FLOAT NOT NULL DEFAULT 0,
    max_sim_fps FLOAT NOT NULL DEFAULT 0,
    mode_sim_fps FLOAT NOT NULL DEFAULT 0,
    start_time FLOAT NOT NULL DEFAULT 0,
    client_version VARCHAR(255) NOT NULL DEFAULT '',
    s_cpu VARCHAR(255) NOT NULL DEFAULT '',
    s_gpu VARCHAR(255) NOT NULL DEFAULT '',
    s_os VARCHAR(2255) NOT NULL DEFAULT '',
    s_ram INT NOT NULL DEFAULT 0,
    d_object_kb FLOAT NOT NULL DEFAULT 0,
    d_texture_kb FLOAT NOT NULL DEFAULT 0,
    d_world_kb FLOAT NOT NULL DEFAULT 0,
    n_in_kb FLOAT NOT NULL DEFAULT 0,
    n_in_pk INT NOT NULL DEFAULT 0,
    n_out_kb FLOAT NOT NULL DEFAULT 0,
    n_out_pk INT NOT NULL DEFAULT 0,
    f_dropped INT NOT NULL DEFAULT 0,
    f_failed_resends INT NOT NULL DEFAULT 0,
    f_invalid INT NOT NULL DEFAULT 0,
    f_off_circuit INT NOT NULL DEFAULT 0,
    f_resent INT NOT NULL DEFAULT 0,
    f_send_packet INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;"""


class SStatsDB:
    """MySQL database wrapper — reads/writes the same table as OpenSim C# module."""

    def __init__(self):
        self.conn = None
        self.connected = False
        self._connect()

    def _connect(self):
        """Connect to MySQL using the same credentials as OpenSim."""
        if not HAS_MYSQL:
            log.warning("MySQL not available — running in DEMO mode")
            return

        try:
            self.conn = MySQLdb.connect(
                host=MYSQL_HOST,
                port=MYSQL_PORT,
                db=MYSQL_DB,
                user=MYSQL_USER,
                passwd=MYSQL_PASS,
                charset=MYSQL_CHARSET,
                autocommit=True
            )
            self.connected = True
            log.info(f"Connected to MySQL: {MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DB}")

            # Create table if it doesn't exist (same schema as C# module)
            self._ensure_table()

        except Exception as e:
            log.error(f"MySQL connection failed: {e}")
            self.connected = False

    def _ensure_table(self):
        """Create the stats_session_data table if it doesn't exist."""
        if not self.connected:
            return
        try:
            cursor = self.conn.cursor()
            cursor.execute(SQL_CREATE_TABLE.format(table=MYSQL_TABLE))
            cursor.close()
            log.info(f"Table `{MYSQL_TABLE}` verified/created")
        except Exception as e:
            log.error(f"Failed to create table: {e}")

    def _reconnect(self):
        """Try to reconnect if connection was lost."""
        try:
            if self.conn:
                self.conn.close()
        except:
            pass
        self._connect()

    def query(self, sql, params=None):
        """Execute a SELECT query and return list of dicts."""
        if not self.connected:
            self._reconnect()
        if not self.connected:
            return []

        try:
            cursor = self.conn.cursor(MySQLdb.cursors.DictCursor)
            cursor.execute(sql, params)
            rows = cursor.fetchall()
            cursor.close()
            return rows
        except MySQLdb.OperationalError:
            log.warning("MySQL connection lost, reconnecting...")
            self._reconnect()
            if self.connected:
                cursor = self.conn.cursor(MySQLdb.cursors.DictCursor)
                cursor.execute(sql, params)
                rows = cursor.fetchall()
                cursor.close()
                return rows
            return []
        except Exception as e:
            log.error(f"Query error: {e}")
            return []

    def execute(self, sql, params=None):
        """Execute an INSERT/UPDATE/DELETE."""
        if not self.connected:
            self._reconnect()
        if not self.connected:
            return 0

        try:
            cursor = self.conn.cursor()
            cursor.execute(sql, params)
            affected = cursor.rowcount
            cursor.close()
            return affected
        except Exception as e:
            log.error(f"Execute error: {e}")
            return 0

    # -------------------------------------------------------------------------
    # Stats Queries (same data the C# Default_Report reads)
    # -------------------------------------------------------------------------

    def get_summary(self):
        """Get summary statistics — same query as C# Default_Report."""
        sql = f"""
            SELECT
                COUNT(DISTINCT agent_id) as total_users,
                COUNT(*) as total_sessions,
                AVG(avg_fps) as avg_client_fps,
                AVG(avg_sim_fps) as avg_sim_fps,
                AVG(avg_ping) as avg_ping,
                SUM(n_out_kb) as total_kb_out,
                SUM(n_in_kb) as total_kb_in,
                AVG(mem_use) as avg_mem_use
            FROM `{MYSQL_TABLE}`
        """
        rows = self.query(sql)
        if rows:
            r = rows[0]
            return {
                "total_users": int(r.get("total_users") or 0),
                "total_sessions": int(r.get("total_sessions") or 0),
                "avg_client_fps": round(float(r.get("avg_client_fps") or 0), 2),
                "avg_sim_fps": round(float(r.get("avg_sim_fps") or 0), 2),
                "avg_ping": round(float(r.get("avg_ping") or 0), 2),
                "total_kb_out": round(float(r.get("total_kb_out") or 0), 2),
                "total_kb_in": round(float(r.get("total_kb_in") or 0), 2),
                "avg_mem_use": round(float(r.get("avg_mem_use") or 0), 2),
            }
        return {}

    def get_client_versions(self):
        """Get client version breakdown — same as C# Clients_report."""
        sql = f"""
            SELECT client_version, COUNT(*) as cnt, AVG(avg_sim_fps) as simfps
            FROM `{MYSQL_TABLE}`
            GROUP BY client_version
            ORDER BY COUNT(*) DESC
            LIMIT 15
        """
        rows = self.query(sql)
        return [
            {
                "version": r["client_version"],
                "count": int(r["cnt"]),
                "avg_fps": round(float(r["simfps"] or 0), 2)
            }
            for r in rows
        ]

    def get_recent_sessions(self, limit=50):
        """Get recent sessions — same as C# Sessions_Report."""
        sql = f"""
            SELECT name_f, name_l, agent_id, session_id, client_version,
                   last_updated, start_time, region_id
            FROM `{MYSQL_TABLE}`
            ORDER BY last_updated DESC
            LIMIT %s
        """
        rows = self.query(sql, (limit,))
        return [
            {
                "name": f"{r['name_f']} {r['name_l']}",
                "agent_id": r["agent_id"],
                "session_id": r["session_id"],
                "client_version": r["client_version"],
                "last_updated": datetime.fromtimestamp(
                    int(r["last_updated"]), tz=timezone.utc
                ).strftime("%Y-%m-%d %H:%M:%S UTC") if r["last_updated"] else "?",
                "region_id": r["region_id"],
            }
            for r in rows
        ]

    def get_active_users(self):
        """Get currently active users (updated in last 5 min)."""
        cutoff = int(time.time()) - 300
        sql = f"""
            SELECT name_f, name_l, agent_id, avg_fps, avg_ping,
                   mem_use, client_version, region_id, last_updated
            FROM `{MYSQL_TABLE}`
            WHERE last_updated > %s
            ORDER BY last_updated DESC
        """
        rows = self.query(sql, (cutoff,))
        return [
            {
                "name": f"{r['name_f']} {r['name_l']}",
                "agent_id": r["agent_id"],
                "fps": round(float(r["avg_fps"] or 0), 1),
                "ping": round(float(r["avg_ping"] or 0), 1),
                "mem_mb": round(float(r["mem_use"] or 0), 1),
                "client": r["client_version"],
                "region_id": r["region_id"],
                "last_seen": datetime.fromtimestamp(
                    int(r["last_updated"]), tz=timezone.utc
                ).strftime("%H:%M:%S") if r["last_updated"] else "?",
            }
            for r in rows
        ]

    def get_region_stats(self):
        """Per-region statistics."""
        sql = f"""
            SELECT region_id,
                   COUNT(DISTINCT agent_id) as users,
                   COUNT(*) as sessions,
                   AVG(avg_fps) as avg_fps,
                   AVG(avg_ping) as avg_ping
            FROM `{MYSQL_TABLE}`
            GROUP BY region_id
            ORDER BY users DESC
        """
        rows = self.query(sql)
        return [
            {
                "region_id": r["region_id"],
                "users": int(r["users"]),
                "sessions": int(r["sessions"]),
                "avg_fps": round(float(r["avg_fps"] or 0), 2),
                "avg_ping": round(float(r["avg_ping"] or 0), 2),
            }
            for r in rows
        ]

    def insert_session(self, data):
        """Insert/update a session record (same as C# INSERT OR REPLACE)."""
        sql = f"""
            INSERT INTO `{MYSQL_TABLE}`
            (session_id, agent_id, region_id, last_updated, remote_ip,
             name_f, name_l, avg_fps, avg_ping, mem_use, client_version,
             s_cpu, s_gpu, s_os, s_ram)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                last_updated=VALUES(last_updated),
                avg_fps=VALUES(avg_fps),
                avg_ping=VALUES(avg_ping),
                mem_use=VALUES(mem_use)
        """
        return self.execute(sql, (
            data.get("session_id", str(secrets.token_hex(16))),
            data.get("agent_id", ""),
            data.get("region_id", ""),
            data.get("last_updated", int(time.time())),
            data.get("remote_ip", ""),
            data.get("name_f", ""),
            data.get("name_l", ""),
            data.get("avg_fps", 0),
            data.get("avg_ping", 0),
            data.get("mem_use", 0),
            data.get("client_version", ""),
            data.get("s_cpu", ""),
            data.get("s_gpu", ""),
            data.get("s_os", ""),
            data.get("s_ram", 0),
        ))

    def get_table_info(self):
        """Get table row count and size."""
        sql = f"SELECT COUNT(*) as cnt FROM `{MYSQL_TABLE}`"
        rows = self.query(sql)
        return {"row_count": int(rows[0]["cnt"]) if rows else 0}


# =============================================================================
# Session & Auth Management
# =============================================================================
sessions = {}
login_attempts = {}


def generate_session_token(username):
    token = secrets.token_urlsafe(32)
    now = time.time()
    sessions[token] = {"user": username, "created": now, "last_access": now}
    return token


def validate_session(token):
    if not token or token not in sessions:
        return None
    sess = sessions[token]
    if time.time() - sess["last_access"] > SESSION_TIMEOUT:
        del sessions[token]
        return None
    sess["last_access"] = time.time()
    return sess["user"]


def check_rate_limit(ip):
    if ip in login_attempts:
        info = login_attempts[ip]
        if info.get("lockout_until", 0) > time.time():
            return False
    return True


def record_failed_login(ip):
    now = time.time()
    if ip not in login_attempts:
        login_attempts[ip] = {"count": 0, "lockout_until": 0}
    info = login_attempts[ip]
    info["count"] += 1
    if info["count"] >= MAX_LOGIN_ATTEMPTS:
        info["lockout_until"] = now + LOGIN_LOCKOUT_SECONDS
        info["count"] = 0
        log.warning(f"IP {ip} locked out for {LOGIN_LOCKOUT_SECONDS}s")


def clear_failed_login(ip):
    login_attempts.pop(ip, None)


# =============================================================================
# Dashboard HTML
# =============================================================================
DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SStats Dashboard — OpenSim Statistics</title>
<meta http-equiv="refresh" content="30">
<style>
  * {{ margin:0; padding:0; box-sizing:border-box; }}
  body {{ font-family:'Segoe UI',system-ui,sans-serif; background:#0a0e1a; color:#e0e0e0; min-height:100vh; }}
  .header {{ background:linear-gradient(135deg,#1a1f3a,#0d1225); padding:20px 30px; border-bottom:1px solid #1e2740; display:flex; justify-content:space-between; align-items:center; }}
  .header h1 {{ font-size:22px; background:linear-gradient(90deg,#00d2ff,#7b61ff); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }}
  .header .meta {{ font-size:12px; color:#667; }}
  .header a {{ color:#7b61ff; text-decoration:none; font-size:13px; }}
  .container {{ max-width:1200px; margin:0 auto; padding:20px; }}
  .grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:16px; margin:20px 0; }}
  .card {{ background:rgba(255,255,255,0.03); border:1px solid #1e2740; border-radius:12px; padding:20px; text-align:center; }}
  .card .value {{ font-size:32px; font-weight:700; color:#00d2ff; margin:8px 0; }}
  .card .label {{ font-size:12px; color:#667; text-transform:uppercase; letter-spacing:1px; }}
  .section {{ background:rgba(255,255,255,0.02); border:1px solid #1e2740; border-radius:12px; padding:20px; margin:20px 0; }}
  .section h2 {{ font-size:16px; color:#7b61ff; margin-bottom:12px; }}
  table {{ width:100%; border-collapse:collapse; font-size:13px; }}
  th {{ text-align:left; padding:8px 12px; color:#667; border-bottom:1px solid #1e2740; font-weight:600; text-transform:uppercase; font-size:11px; letter-spacing:1px; }}
  td {{ padding:8px 12px; border-bottom:1px solid #0f1525; }}
  tr:hover td {{ background:rgba(123,97,255,0.05); }}
  .status {{ display:inline-block; width:8px; height:8px; border-radius:50%; margin-right:6px; }}
  .status.online {{ background:#4caf50; }}
  .status.stale {{ background:#ff9800; }}
  .empty {{ color:#444; font-style:italic; padding:20px; text-align:center; }}
  .db-info {{ font-size:11px; color:#444; text-align:center; padding:10px; border-top:1px solid #1e2740; margin-top:20px; }}
</style>
</head>
<body>
<div class="header">
  <div>
    <h1>&#x1F4CA; SStats Dashboard</h1>
    <div class="meta">OpenSim Statistics &bull; MySQL: {db_host}/{db_name} &bull; Auto-refresh 30s</div>
  </div>
  <div>
    <a href="/logout">&#x1F6AA; Logout</a>
    &nbsp;&nbsp;
    <a href="/api/stats?format=json">&#x1F4E4; JSON API</a>
  </div>
</div>
<div class="container">
  <div class="grid">
    <div class="card">
      <div class="label">Active Users</div>
      <div class="value">{total_users}</div>
    </div>
    <div class="card">
      <div class="label">Total Sessions</div>
      <div class="value">{total_sessions}</div>
    </div>
    <div class="card">
      <div class="label">Avg Client FPS</div>
      <div class="value">{avg_fps}</div>
    </div>
    <div class="card">
      <div class="label">Avg Sim FPS</div>
      <div class="value">{avg_sim_fps}</div>
    </div>
    <div class="card">
      <div class="label">Avg Ping</div>
      <div class="value">{avg_ping}ms</div>
    </div>
    <div class="card">
      <div class="label">Avg Memory</div>
      <div class="value">{avg_mem}MB</div>
    </div>
    <div class="card">
      <div class="label">KB Out</div>
      <div class="value">{kb_out}</div>
    </div>
    <div class="card">
      <div class="label">KB In</div>
      <div class="value">{kb_in}</div>
    </div>
  </div>

  <div class="section">
    <h2>&#x1F464; Active Users (last 5 min)</h2>
    {active_users_html}
  </div>

  <div class="section">
    <h2>&#x1F4CA; Client Versions</h2>
    {client_versions_html}
  </div>

  <div class="section">
    <h2>&#x1F552; Recent Sessions</h2>
    {sessions_html}
  </div>

  <div class="db-info">
    SStats MySQL Dashboard &bull; Table: {table_name} &bull; Rows: {row_count} &bull; {timestamp}
  </div>
</div>
</body>
</html>"""

LOGIN_PAGE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SStats — Login Required</title>
<style>
  * {{ margin:0;padding:0;box-sizing:border-box; }}
  body {{ font-family:'Segoe UI',system-ui,sans-serif; background:linear-gradient(135deg,#0f0c29,#302b63,#24243e); min-height:100vh; display:flex; align-items:center; justify-content:center; color:#fff; }}
  .box {{ background:rgba(255,255,255,0.05); backdrop-filter:blur(10px); border:1px solid rgba(255,255,255,0.1); border-radius:16px; padding:40px; width:380px; box-shadow:0 8px 32px rgba(0,0,0,0.3); }}
  .box h1 {{ text-align:center; font-size:24px; margin-bottom:8px; background:linear-gradient(90deg,#00d2ff,#7b61ff); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }}
  .box .sub {{ text-align:center; color:rgba(255,255,255,0.6); font-size:14px; margin-bottom:30px; }}
  .field {{ margin-bottom:20px; }}
  .field label {{ display:block; margin-bottom:6px; font-size:12px; color:rgba(255,255,255,0.7); text-transform:uppercase; letter-spacing:1px; }}
  .field input {{ width:100%; padding:12px 16px; border:1px solid rgba(255,255,255,0.15); border-radius:8px; background:rgba(255,255,255,0.08); color:#fff; font-size:15px; outline:none; }}
  .field input:focus {{ border-color:#7b61ff; }}
  .btn {{ width:100%; padding:14px; border:none; border-radius:8px; background:linear-gradient(90deg,#00d2ff,#7b61ff); color:#fff; font-size:16px; font-weight:600; cursor:pointer; }}
  .btn:hover {{ opacity:0.9; }}
  .err {{ background:rgba(255,50,50,0.15); border:1px solid rgba(255,50,50,0.3); border-radius:8px; padding:10px; margin-bottom:20px; font-size:13px; color:#ff6b6b; text-align:center; }}
</style>
</head>
<body>
<div class="box">
  <h1>&#x1F4CA; SStats</h1>
  <div class="sub">OpenSim Statistics Dashboard</div>
  {error_html}
  <form method="POST" action="/login">
    <div class="field"><label>Username</label><input type="text" name="username" required autofocus></div>
    <div class="field"><label>Password</label><input type="password" name="password" required></div>
    <button type="submit" class="btn">Sign In</button>
  </form>
</div>
</body>
</html>"""


def build_table(rows, columns):
    """Build an HTML table from rows (list of dicts) and column specs [(key, label)]."""
    if not rows:
        return '<div class="empty">No data available</div>'
    html_parts = ["<table><tr>"]
    for key, label in columns:
        html_parts.append(f"<th>{label}</th>")
    html_parts.append("</tr>")
    for row in rows:
        html_parts.append("<tr>")
        for key, label in columns:
            html_parts.append(f"<td>{html.escape(str(row.get(key, '')))}</td>")
        html_parts.append("</tr>")
    html_parts.append("</table>")
    return "\n".join(html_parts)


# =============================================================================
# HTTP Handler
# =============================================================================
class SStatsHandler(BaseHTTPRequestHandler):
    db = None  # Set by main()

    server_version = "SStats-MySQL/1.0"

    def log_message(self, fmt, *args):
        log.info(f"{self.client_address[0]} - {fmt % args}")

    def _get_ip(self):
        return self.client_address[0]

    def _extract_auth(self):
        auth = self.headers.get("Authorization", "")
        if auth.startswith("Basic "):
            try:
                u, p = base64.b64decode(auth[6:]).decode().split(":", 1)
                return u, p
            except:
                pass
        return None, None

    def _get_cookie(self, name):
        for part in self.headers.get("Cookie", "").split(";"):
            part = part.strip()
            if part.startswith(f"{name}="):
                return part[len(name)+1:]
        return None

    def _send_login(self, error=None):
        err = f'<div class="err">{html.escape(error)}</div>' if error else ""
        body = LOGIN_PAGE.format(error_html=err).encode()
        self.send_response(401)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("WWW-Authenticate", 'Basic realm="SStats"')
        self.end_headers()
        self.wfile.write(body)

    def _send_html(self, body_str, code=200):
        body = body_str.encode()
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
        self.end_headers()
        self.wfile.write(body)

    def _send_json(self, data, code=200):
        body = json.dumps(data, indent=2, default=str).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _check_auth(self):
        token = self._get_cookie("sstats_session")
        if validate_session(token):
            return True
        u, p = self._extract_auth()
        if u and p:
            ip = self._get_ip()
            if not check_rate_limit(ip):
                self._send_login("Too many attempts. Please wait.")
                return False
            if u == PROXY_USERNAME and p == PROXY_PASSWORD:
                clear_failed_login(ip)
                return True
            else:
                record_failed_login(ip)
                return False
        return False

    def _build_dashboard(self):
        db = self.db
        summary = db.get_summary() if db and db.connected else {}
        active = db.get_active_users() if db and db.connected else []
        versions = db.get_client_versions() if db and db.connected else []
        recent = db.get_recent_sessions(30) if db and db.connected else []
        info = db.get_table_info() if db and db.connected else {"row_count": 0}

        active_html = build_table(active, [
            ("name", "Name"), ("fps", "FPS"), ("ping", "Ping"),
            ("mem_mb", "Mem MB"), ("client", "Client"), ("last_seen", "Last Seen")
        ])
        versions_html = build_table(versions, [
            ("version", "Client Version"), ("count", "Count"), ("avg_fps", "Avg FPS")
        ])
        sessions_html = build_table(recent, [
            ("name", "Name"), ("client_version", "Client"), ("last_updated", "Last Updated"), ("region_id", "Region")
        ])

        return DASHBOARD_HTML.format(
            db_host=MYSQL_HOST,
            db_name=MYSQL_DB,
            table_name=MYSQL_TABLE,
            total_users=summary.get("total_users", 0),
            total_sessions=summary.get("total_sessions", 0),
            avg_fps=summary.get("avg_client_fps", 0),
            avg_sim_fps=summary.get("avg_sim_fps", 0),
            avg_ping=summary.get("avg_ping", 0),
            avg_mem=summary.get("avg_mem_use", 0),
            kb_out=summary.get("total_kb_out", 0),
            kb_in=summary.get("total_kb_in", 0),
            active_users_html=active_html,
            client_versions_html=versions_html,
            sessions_html=sessions_html,
            row_count=info.get("row_count", 0),
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        )

    # --- HTTP methods ---

    def do_GET(self):
        path = urlparse(self.path).path

        if path == "/health":
            self._send_json({
                "status": "ok",
                "mysql": self.db.connected if self.db else False,
                "table": MYSQL_TABLE
            })
            return

        if path == "/login":
            self._send_login()
            return

        if path == "/logout":
            t = self._get_cookie("sstats_session")
            if t and t in sessions:
                del sessions[t]
            self.send_response(302)
            self.send_header("Location", "/login")
            self.send_header("Set-Cookie", "sstats_session=; Path=/; Max-Age=0")
            self.end_headers()
            return

        if path == "/api/stats":
            if not self._check_auth():
                self._send_login("Authentication required.")
                return
            data = {
                "summary": self.db.get_summary() if self.db and self.db.connected else {},
                "active_users": self.db.get_active_users() if self.db and self.db.connected else [],
                "client_versions": self.db.get_client_versions() if self.db and self.db.connected else [],
                "recent_sessions": self.db.get_recent_sessions(20) if self.db and self.db.connected else [],
                "table_info": self.db.get_table_info() if self.db and self.db.connected else {},
            }
            self._send_json(data)
            return

        if path == "/" or path == "/stats" or path == "/stats/":
            if not self._check_auth():
                self._send_login("Invalid credentials.")
                return
            self._send_html(self._build_dashboard())
            return

        self.send_response(404)
        self.end_headers()

    def do_POST(self):
        path = urlparse(self.path).path

        if path == "/login":
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length).decode()
            params = dict(parse_qs(body))
            u = params.get("username", [""])[0]
            p = params.get("password", [""])[0]
            ip = self._get_ip()

            if not check_rate_limit(ip):
                self._send_login("Too many attempts.")
                return

            if u == PROXY_USERNAME and p == PROXY_PASSWORD:
                clear_failed_login(ip)
                token = generate_session_token(u)
                self.send_response(302)
                self.send_header("Location", "/stats/")
                self.send_header("Set-Cookie",
                    f"sstats_session={token}; Path=/; HttpOnly; SameSite=Lax; Max-Age={SESSION_TIMEOUT}")
                self.end_headers()
                return
            else:
                record_failed_login(ip)
                self._send_login("Invalid username or password.")
                return

        if path == "/api/stats":
            if not self._check_auth():
                self._send_login("Auth required.")
                return
            # Insert stats from external source (e.g. C# module pushing data)
            length = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(length))
            affected = self.db.insert_session(body) if self.db else 0
            self._send_json({"inserted": affected})
            return

        self.send_response(404)
        self.end_headers()


# =============================================================================
# Main
# =============================================================================
def main():
    db = SStatsDB()

    print(f"""
    ╔══════════════════════════════════════════════════════╗
    ║       SStats MySQL Dashboard                       ║
    ║       Password-Shielded OpenSim Statistics          ║
    ╠══════════════════════════════════════════════════════╣
    ║  URL:      http://{PROXY_HOST}:{PROXY_PORT:<21}║
    ║  MySQL:    {MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DB:<18}║
    ║  Table:    {MYSQL_TABLE:<33}║
    ║  User:     {PROXY_USERNAME:<33}║
    ║  DB Conn:  {'OK' if db.connected else 'FAILED (check credentials)':<33}║
    ╚══════════════════════════════════════════════════════╝
    """)

    SStatsHandler.db = db
    server = HTTPServer((PROXY_HOST, PROXY_PORT), SStatsHandler)
    log.info(f"SStats MySQL Dashboard on {PROXY_HOST}:{PROXY_PORT}")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        log.info("Shutting down...")
        server.shutdown()
        if db.conn:
            db.conn.close()


if __name__ == "__main__":
    main()
