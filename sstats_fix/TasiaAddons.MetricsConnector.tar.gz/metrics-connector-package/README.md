# TasiaAddons.MetricsConnector

## What it does
An OpenSim region addon module that collects per-region metrics and exposes them via HTTP API. This replaces dotnet-monitor for metrics collection — no .NET IPC event pipe needed.

## Features
- Collects sim stats every N seconds (FPS, agents, objects, scripts, memory, uptime)
- HTTP endpoint per region: `/tasia-ngc/metrics/{regionID}`
- API token authentication (Bearer header)
- JSON response with all metrics
- Tracks HTTP endpoint call counts and timing

## Installation

1. Build `TasiaAddons.MetricsConnector.csproj` (targets net8.0)
2. Copy `TasiaAddons.MetricsConnector.dll` to the sim's `bin/` directory
3. Add `[MetricsConnector]` section to shared config (e.g., `GridCommon.ini` or `config-include/GridCommon.ini`):

```ini
[MetricsConnector]
    Enabled = true
    ApiEnabled = true
    ApiToken = YOUR_SECRET_TOKEN_HERE
    CollectIntervalSeconds = 10
```

4. Restart sims

## API

### GET `/tasia-ngc/metrics/{regionUUID}`

**Headers:**
```
Authorization: Bearer YOUR_SECRET_TOKEN_HERE
```

**Response:**
```json
{
  "region_name": "River-Retreat",
  "sim_fps": 45.2,
  "physics_fps": 45.0,
  "agents": 5,
  "child_agents": 2,
  "objects": 1234,
  "active_scripts": 56,
  "memory_mb": 1024,
  "uptime_seconds": 3600,
  "object_updates": 12,
  "endpoints": {
    "/assets/": {"calls": 1234, "avg_ms": 12.5, "total_ms": 15420}
  }
}
```

**401 Response:**
```json
{"error":"unauthorized"}
```

## Config Options

| Key | Default | Description |
|-----|---------|-------------|
| `Enabled` | false | Enable the module |
| `ApiEnabled` | false | Enable HTTP API endpoint |
| `ApiToken` | empty | Bearer token for API auth |
| `ApiPathPrefix` | `/tasia-ngc/metrics` | API URL prefix |
| `CollectIntervalSeconds` | 10 | How often to collect stats |

## Architecture

```
Sim (OpenSim.dll)
  └─ MetricsConnector (ISharedRegionModule)
       ├─ Timer: collects stats every 10s
       │   └─ Scene.StatsReporter (FPS, agents, etc.)
       │   └─ GC.GetTotalMemory (memory usage)
       │   └─ Process uptime
       └─ HTTP Handler: /tasia-ngc/metrics/{regionID}
           └─ Returns JSON with all collected metrics
```

## Notes
- No dotnet-monitor dependency — collects metrics directly from OpenSim internals
- Works with any OpenSim build (no .NET IPC event pipe needed)
- API token same format as TasiaAddons.RestartModule
- Region UUID is lowercase in the URL path
