using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Reflection;
using System.Text;
using System.Timers;
using System.Xml.Serialization;
using log4net;
using Mono.Addins;
using Nini.Config;
using OpenMetaverse;
using OpenSim.Framework;
using OpenSim.Framework.Servers;
using OpenSim.Framework.Servers.HttpServer;
using OpenSim.Region.Framework.Interfaces;
using OpenSim.Region.Framework.Scenes;
using Timer = System.Timers.Timer;

[assembly: Addin("TasiaAddons.MetricsConnector", "1.0.0")]
[assembly: AddinDescription("Tasia Metrics Connector — collects sim stats + HTTP endpoint metrics")]
[assembly: AddinDependency("OpenSim.Region.Framework", OpenSim.VersionInfo.VersionNumber)]

namespace TasiaAddons.MetricsConnector
{
    [Extension(Path = "/OpenSim/RegionModules", NodeName = "RegionModule", Id = "MetricsConnector")]
    public class MetricsConnector : INonSharedRegionModule
    {
        private static readonly ILog m_log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        private Scene m_scene;
        private bool m_enabled;
        private bool m_apiEnabled;
        private string m_apiToken;
        private string m_apiPath;
        private Timer m_collectTimer;

        // Endpoint tracking: key = HTTP path, value = (callCount, totalMs, recentMs)
        private readonly ConcurrentDictionary<string, EndpointStats> m_endpoints = new();

        // Current snapshot
        private MetricsSnapshot m_snapshot = new();

        public void Initialise(IConfigSource config)
        {
            IConfig cfg = config.Configs["MetricsConnector"];
            if (cfg == null)
                return;

            m_enabled = cfg.GetBoolean("Enabled", false);
            if (!m_enabled)
                return;

            m_apiEnabled = cfg.GetBoolean("ApiEnabled", false);
            m_apiToken = cfg.GetString("ApiToken", string.Empty);
            if (m_apiToken == "CHANGE_ME_METRICS_TOKEN")
                m_apiToken = string.Empty;

            int interval = cfg.GetInt("CollectIntervalSeconds", 10);
            if (interval < 5)
                interval = 5;

            m_collectTimer = new Timer(interval * 1000);
            m_collectTimer.AutoReset = true;
            m_collectTimer.Elapsed += CollectMetrics;
            m_collectTimer.Start();
        }

        public void AddRegion(Scene scene)
        {
            if (!m_enabled)
                return;

            m_scene = scene;

            if (m_apiEnabled && !string.IsNullOrWhiteSpace(m_apiToken))
            {
                string prefix = "/tasia-ngc/metrics";
                m_apiPath = $"{prefix}/{scene.RegionInfo.RegionID.ToString().ToLowerInvariant()}";

                try
                {
                    MainServer.Instance.AddSimpleStreamHandler(
                        new SimpleStreamHandler(m_apiPath, HandleApiRequest, Name + ".API"));
                    m_log.InfoFormat("[METRICS] API enabled for {0} at {1}", scene.RegionInfo.RegionName, m_apiPath);
                }
                catch (Exception ex)
                {
                    m_log.ErrorFormat("[METRICS] Failed to register API: {0}", ex.Message);
                }
            }
        }

        public void RemoveRegion(Scene scene)
        {
            if (!m_enabled)
                return;

            m_collectTimer?.Stop();
            m_collectTimer?.Dispose();
            m_collectTimer = null;

            if (!string.IsNullOrEmpty(m_apiPath))
            {
                try
                {
                    MainServer.Instance.RemoveSimpleStreamHandler(m_apiPath);
                }
                catch { }
                m_apiPath = null;
            }

            m_scene = null;
        }

        public void Close() { }
        public void Dispose() { RemoveRegion(m_scene); }
        public string Name => "MetricsConnector";
        public Type ReplaceableInterface => null;
        public void RegionLoaded(Scene scene) { }

        // === HTTP API ===

        private void HandleApiRequest(IOSHttpRequest request, IOSHttpResponse response)
        {
            response.ContentType = "application/json";

            if (!IsAuthorized(request))
            {
                WriteJson(response, 401, "{\"error\":\"unauthorized\"}");
                return;
            }

            var snap = m_snapshot;
            var sb = new StringBuilder();
            sb.Append('{');
            sb.AppendFormat("\"region_name\":\"{0}\",", Escape(snap.RegionName));
            sb.AppendFormat("\"sim_fps\":{0:F1},", snap.SimFPS);
            sb.AppendFormat("\"physics_fps\":{0:F1},", snap.PhysicsFPS);
            sb.AppendFormat("\"agents\":{0},", snap.RootAgents);
            sb.AppendFormat("\"child_agents\":{0},", snap.ChildAgents);
            sb.AppendFormat("\"objects\":{0},", snap.TotalPrims);
            sb.AppendFormat("\"active_scripts\":{0},", snap.ActiveScripts);
            sb.AppendFormat("\"memory_mb\":{0:F0},", snap.MemoryMB);
            sb.AppendFormat("\"uptime_seconds\":{0},", snap.UptimeSeconds);
            sb.AppendFormat("\"object_updates\":{0:F0},", snap.ObjectUpdates);

            // Endpoint stats
            sb.Append("\"endpoints\":{");
            bool first = true;
            foreach (var kv in m_endpoints)
            {
                var es = kv.Value;
                if (es.TotalCalls == 0) continue;
                if (!first) sb.Append(',');
                first = false;
                sb.AppendFormat("\"{0}\":{{\"calls\":{1},\"avg_ms\":{2:F1},\"total_ms\":{3:F0}}}",
                    Escape(kv.Key), es.TotalCalls, es.AvgMs, es.TotalMs);
            }
            sb.Append("}");

            sb.Append('}');
            WriteJson(response, 200, sb.ToString());
        }

        private void CollectMetrics(object sender, ElapsedEventArgs e)
        {
            if (m_scene == null)
                return;

            try
            {
                var snap = new MetricsSnapshot();
                snap.RegionName = m_scene.RegionInfo.RegionName;
                snap.SimFPS = m_scene.StatsReporter.LastReportedSimFPS;

                float[] stats = m_scene.StatsReporter.LastReportedSimStats;
                if (stats != null && stats.Length > 30)
                {
                    snap.PhysicsFPS = stats[1];
                    snap.RootAgents = (int)stats[3];
                    snap.ChildAgents = (int)stats[4];
                    snap.TotalPrims = (int)stats[5];
                    snap.ActiveScripts = (int)stats[6];
                    snap.ObjectUpdates = stats[2];
                }

                snap.MemoryMB = GC.GetTotalMemory(false) / (1024.0 * 1024.0);
                snap.UptimeSeconds = (long)(DateTime.UtcNow - Process.GetCurrentProcess().StartTime.ToUniversalTime()).TotalSeconds;

                m_snapshot = snap;
            }
            catch (Exception ex)
            {
                m_log.WarnFormat("[METRICS] Collect failed: {0}", ex.Message);
            }
        }

        // === Instrument HTTP requests ===

        public void TrackRequest(string path, double elapsedMs)
        {
            var stats = m_endpoints.GetOrAdd(path, _ => new EndpointStats());
            Interlocked.Increment(ref stats.TotalCalls);
            Interlocked.Add(ref stats.TotalMsAccum, (long)(elapsedMs * 1000));
        }

        // === Helpers ===

        private bool IsAuthorized(IOSHttpRequest request)
        {
            string auth = request.Headers["Authorization"] ?? string.Empty;
            if (auth.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
                return auth.Substring(7).Trim() == m_apiToken;
            return (request.Headers["X-Metrics-Token"] ?? string.Empty) == m_apiToken;
        }

        private static void WriteJson(IOSHttpResponse response, int code, string json)
        {
            byte[] data = Encoding.UTF8.GetBytes(json);
            response.ContentLength = data.Length;
            response.StatusCode = code;
            response.Body.Write(data, 0, data.Length);
        }

        private static string Escape(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("\\", "\\\\").Replace("\"", "\\\"");
        }

        // === Data types ===

        private struct MetricsSnapshot
        {
            public string RegionName;
            public float SimFPS;
            public float PhysicsFPS;
            public int RootAgents;
            public int ChildAgents;
            public int TotalPrims;
            public int ActiveScripts;
            public double MemoryMB;
            public long UptimeSeconds;
            public float ObjectUpdates;
        }

        private class EndpointStats
        {
            public long TotalCalls;
            public long TotalMsAccum;
            public double AvgMs => TotalCalls > 0 ? (double)TotalMsAccum / TotalCalls / 1000.0 : 0;
            public double TotalMs => (double)TotalMsAccum / 1000.0;
        }
    }
}
